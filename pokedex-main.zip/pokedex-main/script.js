// Global variables
let allPokemonData = [];
let allUniqueTypes = [];
let filteredPokemonData = [];
let currentPage = 1;
let pokemonPerPage = 14;
let isLoading = false;
let currentSearchTerm = '';
let currentTypeFilter = 'all';

// fetch pokemon from pokeAPI
async function fetchAllPokemon() {
    if (isLoading) return;
    isLoading = true;

    // try fetching pokemon 
    try {
        console.log("Fetching Pokemon list...");
        const initialResponse = await fetch("https://pokeapi.co/api/v2/pokemon/?limit=1");
        const initialData = await initialResponse.json();
        const totalPokemon = initialData.count;

        console.log(`Found ${totalPokemon} Pokemon.`);

        const allPokemonResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/?limit=${totalPokemon}`);
        const allPokemonList = await allPokemonResponse.json();

        console.log("Fetching details of pokemon");

        const pokemonDetails = await Promise.all(
            allPokemonList.results.map(async (pokemon, index) => {
                try {
                    const pokemonResponse = await fetch(pokemon.url);
                    const pokemonData = await pokemonResponse.json();
                    return pokemonData;

                } catch (error) {

                    console.error(`Failed to fetch ${pokemon.name}:`, error);
                    return null;
                }
            })
        );

        const validPokemonDetails = pokemonDetails.filter(pokemon => pokemon !== null); // filter-out pokemon that came up as null/ didn't load in.

        const allTypes = validPokemonDetails.flatMap(pokemon =>
            pokemon.types.map(type => type.type.name)
        );
        allUniqueTypes = [...new Set(allTypes)].sort();

        allPokemonData = validPokemonDetails.map(pokemon => ({
            name: pokemon.name,
            image: pokemon.sprites.other['official-artwork'].front_default ||
                pokemon.sprites.front_default,
            id: pokemon.id,
            types: pokemon.types.map(type => type.type.name),
            stats: {
                hp: pokemon.stats.find(stat => stat.stat.name === 'hp').base_stat,
                attack: pokemon.stats.find(stat => stat.stat.name === 'attack').base_stat,
                defense: pokemon.stats.find(stat => stat.stat.name === 'defense').base_stat,
                specialAttack: pokemon.stats.find(stat => stat.stat.name === 'special-attack').base_stat,
                specialDefense: pokemon.stats.find(stat => stat.stat.name === 'special-defense').base_stat,
                speed: pokemon.stats.find(stat => stat.stat.name === 'speed').base_stat
            },
            moves: pokemon.moves.map(move => move.move.name)
        }));

        filteredPokemonData = [...allPokemonData];

        console.log(`Successfully loaded ${allPokemonData.length} Pokemon!`);
        console.log("Unique types:", allUniqueTypes);
        
        
        createTypeFilters();
        createPaginationButtons();
        setupSearchFunctionality();
        updateDisplay();

        isLoading = false;
        return allPokemonData;

    } catch (error) {
        console.error("Error loading Pokemon:", error);
        isLoading = false;
    }
}

// setup search
function setupSearchFunctionality() {
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-btn');

    searchButton.addEventListener('click', performSearch);

    searchInput.addEventListener('keypress', function (event) {
        if (event.key === 'Enter') {
            performSearch();
        }
    });
}

// search function
function performSearch() {
    const searchInput = document.querySelector('.search-input');
    const searchTerm = searchInput.value.toLowerCase().trim();

    currentSearchTerm = searchTerm;
    applyFilters();
}

// clear search
function clearSearch() {
    const searchInput = document.querySelector('.search-input');
    searchInput.value = '';
    currentSearchTerm = '';
    applyFilters();
}

// apply search and type filters together
function applyFilters() {
    let filtered = [...allPokemonData];

    // search filter
    if (currentSearchTerm) {
        filtered = filtered.filter(pokemon => {
            const nameMatch = pokemon.name.toLowerCase().includes(currentSearchTerm);
            const typeMatch = pokemon.types.some(type =>
                type.toLowerCase().includes(currentSearchTerm)
            );
            const moveMatch = pokemon.moves.some(move =>
                move.toLowerCase().includes(currentSearchTerm)
            );

            return nameMatch || typeMatch || moveMatch;
        });
    }

    // type filter
    if (currentTypeFilter !== 'all') {
        filtered = filtered.filter(pokemon =>
            pokemon.types.includes(currentTypeFilter)
        );
    }

    filteredPokemonData = filtered;
    currentPage = 1; // start back at page one when filtering
    updateDisplay();

    console.log(`Filtered to ${filteredPokemonData.length} Pokemon`);
}

// functions for pages
function nextPage() {
    const maxPage = Math.ceil(filteredPokemonData.length / pokemonPerPage);
    if (currentPage < maxPage) {
        currentPage++;
        updateDisplay();
    }
}

function previousPage() {
    if (currentPage > 1) {
        currentPage--;
        updateDisplay();
    }
}

function goToPage(page) {
    const maxPage = Math.ceil(filteredPokemonData.length / pokemonPerPage); //math.ceil used to make shure we get full pages and dont cut-off any poki's
    if (page >= 1 && page <= maxPage) {
        currentPage = page;
        updateDisplay();
    }
}

// keep page up to date
function updateDisplay() {
    updatePaginationButtons();
    displayCurrentPage();
}

// display pokemon on current page(new pokemon)
function displayCurrentPage() {
    const startIndex = (currentPage - 1) * pokemonPerPage;
    const endIndex = startIndex + pokemonPerPage;
    const currentPagePokemon = filteredPokemonData.slice(startIndex, endIndex);

    displayPokemonCard(currentPagePokemon);

    console.log(`=== PAGE ${currentPage} ===`);
    console.log(`Showing Pokemon ${startIndex + 1}-${Math.min(endIndex, filteredPokemonData.length)} of ${filteredPokemonData.length}`); // using startIndex +1 so when new page is reached it doesnt show loading 1-20, 1-40 etc of ... instead of 1-20, 21-40 etc. 
    console.log("Current page Pokemon:", currentPagePokemon.map(p => p.name));
}

// update page buttons when a new page is visited.
function updatePaginationButtons() {
    const prevButton = document.getElementById('prev-button');
    const nextButton = document.getElementById('next-button');
    const pageInfo = document.getElementById('page-info');

    const maxPage = Math.ceil(filteredPokemonData.length / pokemonPerPage); // max length of page's, [amount of pokemon(total) / 20] (20 poki's on each page)

    if (pageInfo) {
        pageInfo.textContent = `Page ${currentPage} of ${maxPage}`;
    }

    if (prevButton) {
        prevButton.disabled = currentPage === 1;
    }

    if (nextButton) {
        nextButton.disabled = currentPage === maxPage; // disable button as max page has been reached, all poki's have been caught!!!
    }
}

// create page buttons and info for new pokemons.
function createPaginationButtons() {
    const main = document.querySelector('main');

    const existingPagination = document.getElementById('pagination-container');
    if (existingPagination) {
        existingPagination.remove();
    }

    // create div for the page info and buttons
    const paginationDiv = document.createElement('div');
    paginationDiv.id = 'pagination-container';
    paginationDiv.className = 'pagination-container';

    // previous page button
    const prevButton = document.createElement('button');
    prevButton.id = 'prev-button';
    prevButton.className = 'pagination-btn';
    prevButton.textContent = '← Previous';
    prevButton.onclick = previousPage;

    // page info (page count)
    const pageInfo = document.createElement('span');
    pageInfo.id = 'page-info';
    pageInfo.className = 'page-info';
    pageInfo.textContent = 'Page 1 of 1';

    // next button
    const nextButton = document.createElement('button');
    nextButton.id = 'next-button';
    nextButton.className = 'pagination-btn';
    nextButton.textContent = 'Next →';
    nextButton.onclick = nextPage;

    // append the buttons and thingys
    paginationDiv.appendChild(prevButton);
    paginationDiv.appendChild(pageInfo);
    paginationDiv.appendChild(nextButton);

    const imageContainer = document.getElementById('image-container');
    main.insertBefore(paginationDiv, imageContainer);
}

// create type filters by going thru all types and removing duplicates
function createTypeFilters() {
    const selectElement = document.getElementById('pokemon-types');
    selectElement.innerHTML = "";

    const defaultOption = document.createElement('option'); // default option shows all types
    defaultOption.value = 'all';
    defaultOption.textContent = 'All Types';
    selectElement.appendChild(defaultOption);

    allUniqueTypes.forEach(type => { // create a option for each type of pokemon
        const option = document.createElement('option');
        option.value = type;
        option.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        selectElement.appendChild(option);
    });

    selectElement.addEventListener('change', function () {
        const selectedType = this.value;
        filterPokemonByType(selectedType); // call function to show selected type
    });
}

// selected type will be shown
function filterPokemonByType(selectedType) {
    currentTypeFilter = selectedType;
    applyFilters();

    console.log(`Type filter changed to: ${selectedType}`);
}

// create simple modal popup for pokemon details
function createModal() {
    const existingModal = document.getElementById('pokemon-modal');
    if (existingModal) {
        existingModal.remove();
    }

    const modalHTML = `
        <div id="pokemon-modal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <div class="modal-body">
                    <img id="modal-pokemon-image" src="" alt="" class="modal-pokemon-image">
                    <h2 id="modal-pokemon-name"></h2>
                    <p id="modal-pokemon-id"></p>
                    <div id="modal-pokemon-types"></div>
                    
                    <h3>Stats</h3>
                    <div class="stats-list">
                        <p>HP: <span id="hp-value"></span></p>
                        <p>Attack: <span id="attack-value"></span></p>
                        <p>Defense: <span id="defense-value"></span></p>
                        <p>Sp. Attack: <span id="sp-attack-value"></span></p>
                        <p>Sp. Defense: <span id="sp-defense-value"></span></p>
                        <p>Speed: <span id="speed-value"></span></p>
                    </div>
                    
                    <h3>Some Moves</h3>
                    <div id="modal-pokemon-moves"></div>
                </div>
            </div>
        </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
    setupModalEvents();
}

// setup close modal events
function setupModalEvents() {
    const modal = document.getElementById('pokemon-modal');
    const closeBtn = modal.querySelector('.close');

    // close modal when clicking X
    closeBtn.onclick = function () {
        modal.style.display = 'none';
    }
}

// show modal with pokemon details
function showPokemonModal(pokemon) {
    console.log(`Opening modal for Pokemon: ${pokemon.name} (#${pokemon.id})`);

    let modal = document.getElementById('pokemon-modal');

    if (!modal) {
        console.log("Creating modal for the first time...");
        createModal();
        modal = document.getElementById('pokemon-modal');
    }

    console.log(`Displaying details for: ${pokemon.name}`, pokemon);

    // put pokemon data in modal
    document.getElementById('modal-pokemon-image').src = pokemon.image;
    document.getElementById('modal-pokemon-image').alt = pokemon.name;
    document.getElementById('modal-pokemon-name').textContent = pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1);
    document.getElementById('modal-pokemon-id').textContent = `#${pokemon.id}`;

    // show types
    const typesContainer = document.getElementById('modal-pokemon-types');
    typesContainer.innerHTML = '';
    pokemon.types.forEach(type => {
        const typeSpan = document.createElement('span');
        typeSpan.className = 'type-badge';
        typeSpan.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        typesContainer.appendChild(typeSpan);
    });

    // show stats - simple numbers
    document.getElementById('hp-value').textContent = pokemon.stats.hp;
    document.getElementById('attack-value').textContent = pokemon.stats.attack;
    document.getElementById('defense-value').textContent = pokemon.stats.defense;
    document.getElementById('sp-attack-value').textContent = pokemon.stats.specialAttack;
    document.getElementById('sp-defense-value').textContent = pokemon.stats.specialDefense;
    document.getElementById('speed-value').textContent = pokemon.stats.speed;

    // show some moves, 10 to keep it to a reasonable number
    const movesContainer = document.getElementById('modal-pokemon-moves');
    movesContainer.innerHTML = '';
    const displayMoves = pokemon.moves.slice(0, 10); // show 10 moves/ attacks
    displayMoves.forEach(move => {
        const moveSpan = document.createElement('span');
        moveSpan.className = 'move-badge';
        moveSpan.textContent = move.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
        movesContainer.appendChild(moveSpan);
    });

    // show the modal
    modal.style.display = 'block';
    console.log(`Modal opened successfully for ${pokemon.name}`);
}

function displayPokemonCard(pokemonData) {
    const imgContainer = document.getElementById('image-container');
    imgContainer.innerHTML = "";

    if (pokemonData.length === 0) {
        // show message when no pokemon found
        const noResultsElement = document.createElement('div');
        noResultsElement.className = 'no-results';
        noResultsElement.innerHTML = `
            <h2>No Pokemon Found</h2>
            <p>try adjusting your search</p>
            ${currentSearchTerm ? `<button onclick="clearSearch()" class="clear-search-btn">Clear Search</button>` : ''}
        `;
        imgContainer.appendChild(noResultsElement);
        return;
    }

    // Create a div for each pokemon 
    pokemonData.forEach(pokemon => {
        const pokemonElement = document.createElement('div');
        pokemonElement.className = 'pokemon-card';

        // Add click event to show modal
        pokemonElement.addEventListener('click', () => {
            showPokemonModal(pokemon);
        });

        // Basic structure to display info: img, name, type and hp stat.
        pokemonElement.innerHTML = `
            <img src="${pokemon.image}" alt="${pokemon.name}" class="pokemon-image">
            <p class="pokemon-name">${pokemon.name}</p>
            <p class="pokemon-types">${pokemon.types.join(', ')}</p>
            <p class="pokemon-hp">HP: ${pokemon.stats.hp}</p>
        `;
        imgContainer.appendChild(pokemonElement);
    });
}

function initializeApp() {
    console.log("Initializing program");
    console.log("Loading all pokemon at once");
    setupModalEvents(); // Set up modal events
    fetchAllPokemon(); // Fetch the pokemon
}

initializeApp();

