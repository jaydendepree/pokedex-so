pokédex
<br>
Team:
Adam, Youssef, Jayden, Maximilian, Rayan
<br>
User stories
<br>
<img width="1920" height="1080" alt="image" src="https://github.com/user-attachments/assets/3a291b73-5ed3-44d7-b3f8-a86d98cab9b5" />
reflecties voor ieder persoon.
1. wat kon beter?
2. wat heb ik goed gedaan en waarom.
3. wat heb ik geleerd?
4. wat heb ik toegepast dat ik all wist.


Adam:

1.de user story kon veel beter worden ingedeeld. Of geupdate worden, want vele dingen liepen door elkaar heen waardoor het heel onduidelijk werd wie wat gaat doen. Sommige opdrachten werden uitgevoerd door de onjuiste personen. 

2.Ondanks de uitdagingen is het ons gelukt ons basisidee van een Pokédex te creëren. We hebben een interface gebouwd die 20 Pokémon per pagina toont (om laadtijden te voorkomen), een zoekfunctie op naam en filters op type ookc kunnen de zoekfunctie en filters ook gecombineerd worden.

3.Ik heb geleerd hoe ik efficiënt informatie uit een API kan halen en verwerken. En ik heb geleerd dat als je een planning maakt je heet eerst het best kan volgen hoe die staat en dan iets later verandert. Doordat ik nu beter begrijp hoe ik met API's moet werken, zal dit in de toekomst makkelijker gaan en kan ik meer tijd besteden aan andere onderdelen.

4.  Ik heb al eerder met API fetchen gewerkt, maar is dit iets heel anders en veel leuker, want het gaat om iets wat heel leuks is van jeugd jaren.
   
<br>
<br>
Youssef:

1.  wat kon beter?
   
het verdelen van de taken kon beter het was niet echt duidelijk wie wat moest doen in het midden van het project omdat we de user story langzaam is gaan veranderen waar door we steeds ons afvroegen wat we moeten doen. 
als ik meer tijd had kon ik meer kunnen aanpassen aan de website met css want nu is bijvoorbeeld: de filter niet echt mooi geplaatst en gestyled.

2. wat heb ik goed gedaan en waarom.

ik heb voornamenlijk de css gedaan dus het stylen van de website ging best wel goed. waarom is omdat het zonder moeite is gelukt hoewel het wel langduurde met paar simple dingen maar voor de rest ben ik wel tevreden met de website die we binnen 3 dagen hadden gemaakt hoewel ik keek naar de andere zie ik dat ik nog veel te leren heb als front-end developer.

3. wat heb ik geleerd?

hoe ik beter met css kan om gaan door elkeer te kijken naar de container/div te kijken zodat er zo min mogelijk fout gaat met de css.
dat de planning niet altijd gaat hoe je het verwacht.

4. wat heb ik toegepast dat ik all wist.
   
het responsive maken van de website zodat laptop user en alles der onder tot mobile de website kunnen gebruiken door middel met flexbox en position.


<br>
Jayden:

1. Ik heb de start van de mainpage gedaan en de filterdropdown toegevoegd.

2. Ik heb de filterdropdown goed gedaan aangezien daar veel errors uit kwamen.
 
3. Ik heb geleerd hoe je beter de API kan fetchen en meer data er uit kan halen.

4. Ik heb toegepast dat de filter werkend is en de pagina goed laad.

<br>
<br>
Reflectie van Maximilian:
<br>
1. Wat kon beter?

De manier waarop we de taken verdeelden was niet optimaal. De oorspronkelijke user story veranderde tijdens het project, waardoor niet iedereen zijn deel volledig zelfstandig kon uitvoeren. Hierdoor moest ik regelmatig bijspringen bij anderen, en anderen bij mij. Dit leidde soms tot onduidelijkheid over wie waarmee bezig was en wie er kon pushen naar de repository.

2. Wat ging er goed?
Ondanks de uitdagingen is het ons gelukt ons basisidee van een Pokédex te creëren. We hebben een interface gebouwd die 20 Pokémon per pagina toont (om laadtijden te voorkomen), een zoekfunctie op naam en filters op type ookc kunnen de zoekfunctie en filters ook gecombineerd worden.

3. Wat heb ik geleerd?
Ik heb geleerd hoe ik efficiënt informatie uit een API kan halen en verwerken. Daarnaast heb ik ervaren dat een planning niet altijd verloopt zoals verwacht. Doordat ik nu beter begrijp hoe ik met API's moet werken, zal dit in de toekomst makkelijker gaan en kan ik meer tijd besteden aan andere onderdelen.

4. Wat heb ik toegepast?
Dynamic loading was essentieel voor dit project. Omdat we data uit een API halen, was het niet mogelijk om voor elke Pokémon handmatig HTML-elementen aan te maken. Door dynamisch laden konden we met een loop voor elke geladen Pokémon de juiste informatie en opmaak creëren, wat veel code bespaarde.

<br>
Rayan:
1.
2.
3.
4.
